from enum import Enum


class StorageFormat(Enum):
    CSV = "csv"
    JSON = "json"
