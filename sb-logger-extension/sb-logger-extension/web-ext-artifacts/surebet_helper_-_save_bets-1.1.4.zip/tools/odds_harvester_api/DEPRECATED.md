ODDS HARVESTER (DEPRECATED)
===========================

This directory previously hosted the local OddsHarvester FastAPI server and related utilities.

The OddsHarvester approach has been removed from the active codebase in favor of CSV-based CLV and the player props poller.
The full implementation and historical artifacts are now archived here:

`archive/clv_api_attempts/odds_harvester_api/`

If you need to review or restore the code for debugging or reference, use the archived copy.  This tools path is no longer used by the active extension and will be removed in a future commit.
